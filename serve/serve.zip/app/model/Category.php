<?php
namespace app\model;
use	think\Model;
class Category extends Model{
    //商品类别
}
