<?php
namespace app\model;
use	think\Model;
class AttributeInfo extends Model{
    
    
}
