<?php
namespace app\model;
use	think\Model;
class Frame extends Model{
    //组织机构
}
